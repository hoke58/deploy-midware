#!/bin/bash

MONITOR_PORT=${MONITOR_PORT:-5433}

case "$RUNNING_MODE" in
  monitor)
    RUN_COMMAND="pg_autoctl create monitor --no-ssl --auth=trust --run"
    ;;
  create_node)
    RUN_COMMAND="pg_autoctl create postgres --no-ssl --auth trust --name $HOSTNAME --hostname $HOSTNAME --pg-hba-lan --monitor postgres://autoctl_node@monitor:$MONITOR_PORT/pg_auto_failover?sslmode=prefer"
    ;;
  run_node)
    RUN_COMMAND="pg_autoctl run --name $HOSTNAME --hostname $HOSTNAME"
    ;;
  *)
    RUN_COMMAND="/bin/bash"
esac

if $DOCKER_ROOTLESS_MODE true ;then
    bash -c $RUN_COMMAND
else
    user_id=${HOST_UID:-1000}
    group_id=${HOST_GID:-1000}
    chown -R $user_id:$group_id /var/run/postgresql /var/lib/postgres
    exec gosu $user_id:$group_id $RUN_COMMAND
fi
