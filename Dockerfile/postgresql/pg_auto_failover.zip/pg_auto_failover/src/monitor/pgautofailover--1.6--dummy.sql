--
-- dummy extension update file that does nothing
--
-- complain if script is sourced in psql, rather than via CREATE EXTENSION
\echo Use "ALTER EXTENSION pgautofailover UPDATE TO dummy" to load this file. \quit

